# BioPM Tracker — Final Local MVP

A mobile-friendly universal biomedical preventive-maintenance tracker. It is manufacturer-independent and supports hospitals, equipment, PM scheduling, documents, reports and audit logging.

## Included
- Demo login
- Dashboard
- Hospitals and manufacturers
- Equipment CRUD
- PM scheduling and PM completion
- Dynamic equipment categories
- PM/Test/Installation/Log document upload
- Automatic filename: SERIAL-HOSPITAL-FILETYPE.ext
- Duplicate suffixes -02, -03...
- IndexedDB file storage in the browser
- Print/PDF-ready report
- Responsive mobile UI
- PWA manifest

## Run
Open `index.html` in a modern browser. For best PWA behavior, serve the folder from a local web server.

Demo login is prefilled: admin@biopm.local / admin123.

## Important production note
This build is deliberately local-first and does NOT claim to be connected to a real Firebase project. Before hospital/enterprise deployment, replace demo authentication with Firebase Authentication, move records to Firestore, move files to Firebase Storage, add proper security rules, backups, audit retention, and server-side validation.
